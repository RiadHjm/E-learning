<?php

    echo '<pre>';
    print_r($_FILES);

    $fName = $_FILES['file']['name'];
    $fTemp = $_FILES['file']['tmp_name'];
    $fNew = time().$fName;
    move_uploaded_file($fTemp, 'img/'.$fNew);

?>